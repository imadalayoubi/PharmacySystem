﻿using PharmacySystem.Abstracts;
using PharmacySystem.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PharmacySystem.Models
{
    // ✅ يمثل الموظف ويورث من Person
    public class Employee : Person
    {
        private int _age;
        private decimal _salary;

        // العمر مع تحقق من القيم السالبة
        public int Age
        {
            get => _age;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Age));
                _age = value;
            }
        }

        // الراتب مع تحقق من القيم السالبة
        public decimal Salary
        {
            get => _salary;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Salary));
                _salary = value;
            }
        }

        public DateTime GraduationDate { get; set; }
        public DateTime HireDate { get; set; } = DateTime.Now;

        // يولد معرف الموظف تلقائيًا
        public Employee()
        {
            Id = IdGenerator.NextId();
        }

        // عرض بيانات الموظف
        public override void ShowInfo()
        {
            Console.WriteLine($"Employee ID:{Id}, Name:{Name}, Phone:{Phone}, Age:{Age}, Salary:{Salary:C}");
        }
    }

    // ✅ يمثل الزبون ويورث من Person
    public class Customer : Person
    {
        // إجمالي المشتريات التي قام بها الزبون
        public decimal TotalPurchases { get; private set; }

        // معرف الموظف المرتبط بالزبون (اختياري)
        public int EmployeeID { get; set; }

        public Customer()
        {
            Id = IdGenerator.NextId();
        }

        // إضافة مبلغ إلى إجمالي المشتريات مع تحقق
        public void AddPurchase(decimal amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount));
            TotalPurchases += amount;
        }

        // عرض معلومات الزبون
        public override void ShowInfo()
        {
            Console.WriteLine($"Customer ID:{Id}, Name:{Name}, Phone:{Phone}, Total Purchases:{TotalPurchases:C}");
        }
    }

    // ✅ يمثل مالك النظام ويورث من Person
    public class Owner : Person
    {
        // قفل لحماية العمليات متعددة المسارات
        private readonly object _lock = new object();

        // قائمة الأشخاص (الموظفين والعملاء)
        public List<Person> People { get; private set; } = new List<Person>();

        // قائمة الأصناف في النظام (المستودع والرفوف)
        public List<ItemBase> Items { get; private set; } = new List<ItemBase>();

        // قائمة عمليات الشراء
        public List<Purchase> Purchases { get; private set; } = new List<Purchase>();

        // قائمة عمليات البيع
        public List<SaleRecord> Sales { get; private set; } = new List<SaleRecord>();

        public Owner()
        {
            Id = IdGenerator.NextId();
        }

        // عرض معلومات المالك
        public override void ShowInfo()
        {
            Console.WriteLine($"Owner ID:{Id}, Name:{Name}, Phone:{Phone}");
        }

        // إضافة شخص إلى القائمة مع تحقق وتزامن
        public void AddPerson(Person p)
        {
            if (p == null) throw new ArgumentNullException(nameof(p));
            lock (_lock) { People.Add(p); }
        }

        // إضافة صنف
        public void AddItem(ItemBase item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            lock (_lock) { Items.Add(item); }
        }

        // إضافة عملية شراء
        public void AddPurchase(Purchase p)
        {
            if (p == null) throw new ArgumentNullException(nameof(p));
            lock (_lock) { Purchases.Add(p); }
        }

        // إضافة عملية بيع
        public void AddSale(SaleRecord s)
        {
            if (s == null) throw new ArgumentNullException(nameof(s));
            lock (_lock) { Sales.Add(s); }
        }
    }
}







