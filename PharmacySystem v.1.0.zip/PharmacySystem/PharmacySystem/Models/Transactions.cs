﻿using PharmacySystem.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Models
{
    // يمثل عملية شراء دواء من شركة مبيعات
    public class Purchase
    {
        // رقم الفاتورة (يتم توليده تلقائيًا)
        public int InvoiceID { get; private set; }

        // اسم الدواء
        public string MedicineName { get; set; }

        // الكمية المشتراة
        public int QuantityPurchased { get; set; }

        // سعر الشراء الإجمالي
        public decimal PurchasePrice { get; set; }

        // تاريخ الشراء (القيمة الافتراضية: اليوم الحالي)
        public DateTime PurchaseDate { get; set; } = DateTime.Now;

        // اسم الشركة الموردة
        public string Company { get; internal set; }

        // المُنشئ يحدد رقم الفاتورة تلقائيًا
        public Purchase()
        {
            InvoiceID = IdGenerator.NextId();
        }

        // عرض معلومات عملية الشراء
        public void ShowInfo()
        {
            Console.WriteLine($"Purchase Invoice:{InvoiceID}, Med:{MedicineName}, Qty:{QuantityPurchased}, Price:{PurchasePrice:C}, Date:{PurchaseDate:yyyy-MM-dd}");
        }
    }

    // يمثل سجل عملية بيع
    public class SaleRecord
    {
        // رقم العملية (يتم توليده تلقائيًا)
        public int SaleID { get; private set; }

        // خاصية ID ترجع رقم العملية
        public int Id => SaleID;

        // اسم الدواء المباع
        public string MedicineName { get; set; }

        // الكمية المباعة
        public int QuantitySold { get; set; }

        // سعر الوحدة
        public decimal UnitPrice { get; set; }

        // تاريخ البيع
        public DateTime SaleDate { get; set; } = DateTime.Now;

        // إجمالي السعر (سعر الوحدة × الكمية)
        public decimal TotalPrice => QuantitySold * UnitPrice;

        // اسم آخر لإجمالي السعر
        public decimal TotalAmount => TotalPrice;

        // رقم موظف المبيعات
        public int EmployeeID { get; set; }

        // المُنشئ يحدد رقم البيع تلقائيًا
        public SaleRecord()
        {
            SaleID = IdGenerator.NextId();
        }

        // عرض معلومات عملية البيع
        public void ShowInfo()
        {
            Console.WriteLine(
                $"SaleID:{SaleID}, Med:{MedicineName}, Qty:{QuantitySold}, Unit:{UnitPrice:C}, Total:{TotalPrice:C}, EmployeeID:{EmployeeID}, Date:{SaleDate:yyyy-MM-dd}"
            );
        }
    }
}
