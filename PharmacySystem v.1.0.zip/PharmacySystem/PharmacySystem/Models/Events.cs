﻿using PharmacySystem.Models;
using PharmacySystem.Services;
using System;

namespace PharmacySystem.Events
{
    // ✅ ممثل (delegate) لتعريف حدث إضافة عملية بيع جديدة
    public delegate void SaleAddedHandler(object sender, SaleEventArgs e);

    // ✅ بيانات الحدث المرتبط بإضافة عملية بيع
    public class SaleEventArgs : EventArgs
    {
        // كائن البيع المرتبط بالحدث
        public SaleRecord Sale { get; }

        // التهيئة مع التحقق من القيمة
        public SaleEventArgs(SaleRecord sale)
        {
            Sale = sale ?? throw new ArgumentNullException(nameof(sale));
        }
    }

    // ✅ ممثل لتعريف حدث انخفاض المخزون
    public delegate void LowStockHandler(object sender, LowStockEventArgs e);

    // ✅ بيانات الحدث عند انخفاض كمية صنف في المخزن
    public class LowStockEventArgs : EventArgs
    {
        // الصنف الذي حدث له انخفاض
        public WarehouseItem Item { get; }

        // التهيئة مع التحقق من القيمة
        public LowStockEventArgs(WarehouseItem item)
        {
            Item = item ?? throw new ArgumentNullException(nameof(item));
        }
    }

    // ✅ ممثل لتعريف حدث إضافة عملية شراء جديدة
    public delegate void PurchaseAddedHandler(object sender, PurchaseEventArgs e);

    // ✅ بيانات الحدث المرتبط بإضافة عملية شراء
    public class PurchaseEventArgs : EventArgs
    {
        // كائن الشراء المرتبط بالحدث
        public Purchase Purchase { get; }

        // التهيئة مع التحقق من القيمة
        public PurchaseEventArgs(Purchase purchase)
        {
            Purchase = purchase ?? throw new ArgumentNullException(nameof(purchase));
        }
    }
}













