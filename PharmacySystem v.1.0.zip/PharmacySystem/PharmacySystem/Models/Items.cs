﻿using PharmacySystem.Abstracts;
using PharmacySystem.Utils;
using System;

namespace PharmacySystem.Models
{
    // ✅ صنف يمثل دواء في رفوف الصيدلية
    public class PharmacyItem : ItemBase
    {
        private decimal _price;
        private int _quantity;

        // السعر مع تحقق من القيم السالبة
        public decimal Price
        {
            get => _price;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Price));
                _price = value;
            }
        }

        // الكمية مع تحقق داخلي
        public int Quantity
        {
            get => _quantity;
            private set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Quantity));
                _quantity = value;
            }
        }

        // موقع الدواء في الرفوف
        public string Location { get; set; }

        // معرف الموظف الذي أضاف الدواء
        public int EmployeeID { get; set; }

        // توليد معرف العنصر
        public PharmacyItem()
        {
            Id = IdGenerator.NextId();
        }

        // عرض معلومات الدواء
        public override void ShowInfo()
        {
            Console.WriteLine($"PharmacyItem ID:{Id}, Name:{MedicineName}, Price:{Price:C}, Expiry:{ExpiryDate:yyyy-MM-dd}, Qty:{Quantity}, Loc:{Location}, EmployeeID:{EmployeeID}");
        }

        // تعديل الكمية مع تحقق من السالب
        public void AdjustQuantity(int delta)
        {
            int newQty = Quantity + delta;
            if (newQty < 0) throw new InvalidOperationException("Quantity cannot be negative");
            Quantity = newQty;
        }
    }

    // ✅ صنف يمثل دواء في المخزن
    public class WarehouseItem : ItemBase
    {
        private decimal _shippingPrice;
        private int _quantity;

        // اسم الشركة المصنعة
        public string Company { get; set; }

        // سعر الشحن مع تحقق
        public decimal ShippingPrice
        {
            get => _shippingPrice;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(ShippingPrice));
                _shippingPrice = value;
            }
        }

        // الكمية المخزنة
        public int Quantity
        {
            get => _quantity;
            private set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(Quantity));
                _quantity = value;
            }
        }

        // توليد معرف العنصر
        public WarehouseItem()
        {
            Id = IdGenerator.NextId();
        }

        // عرض بيانات الدواء المخزن
        public override void ShowInfo()
        {
            Console.WriteLine($"WarehouseItem ID:{Id}, Name:{MedicineName}, Company:{Company}, Shipping:{ShippingPrice:C}, Expiry:{ExpiryDate:yyyy-MM-dd}, Qty:{Quantity}");
        }

        // تعديل الكمية مع تحقق من السالب
        public void AdjustQuantity(int delta)
        {
            int newQty = Quantity + delta;
            if (newQty < 0) throw new InvalidOperationException("Quantity cannot be negative");
            Quantity = newQty;
        }
    }
}







