﻿using PharmacySystem.Abstracts;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;
using System.Linq;

namespace PharmacySystem.Services
{
    // فئة مسؤولة عن إدارة الموظفين وتنفيذ العمليات المتعلقة بهم
    public class EmployeeServiceImpl : BaseService, IEmployeeService
    {
        // اسم الخدمة المعروض في الواجهة
        public override string ServiceName => "Employee Management";

        // المُنشئ يستقبل أدوات التفاعل والتسجيل
        public EmployeeServiceImpl(IUserInteractor io, ILogger log) : base(io, log) { }

        // إضافة موظف جديد
        public void AddEmployee(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Add New Employee ===");

            // قراءة البيانات المطلوبة للموظف من المستخدم
            string name = InputValidator.ReadValidatedName("Employee Name");
            string phone = InputValidator.ReadValidatedPhone("Phone");
            int age = InputValidator.ReadValidatedInt("Age");
            decimal salary = InputValidator.ReadValidatedDecimal("Salary");
            DateTime hireDate = InputValidator.ReadValidatedDate("Hire Date");

            // إنشاء كائن موظف جديد
            var newEmployee = new Employee
            {
                Name = name,
                Phone = phone,
                Age = age,
                Salary = (decimal)salary,
                HireDate = hireDate
            };

            // إضافة الموظف إلى قائمة الأشخاص
            owner.AddPerson(newEmployee);

            Console.Clear();
            _log.Info($"Employee '{newEmployee.Name}' added successfully.");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nEmployee added successfully!");
            Console.ResetColor();

            Pause();
        }

        // عرض جميع الموظفين
        public void ListEmployees(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== List of Employees ===");
            Console.ResetColor();

            var employees = owner.People.OfType<Employee>().ToList();

            if (!employees.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No employees found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // طباعة بيانات كل موظف
            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (var emp in employees)
            {
                Console.WriteLine($"Type: {emp.GetType().Name}");
                Console.WriteLine($"ID: {emp.Id}");
                Console.WriteLine($"Name: {emp.Name}");
                Console.WriteLine($"Phone: {emp.Phone}");
                Console.WriteLine($"Age: {emp.Age}");
                Console.WriteLine($"Salary: {emp.Salary}");
                Console.WriteLine($"Hire Date: {emp.HireDate:yyyy-MM-dd}");
                Console.WriteLine(new string('-', 40));
            }

            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Employees: {employees.Count}");
            Console.ResetColor();

            Pause();
        }

        // تعديل بيانات موظف محدد
        public void EditEmployee(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== Edit Employee ===");
            Console.ResetColor();

            var employees = owner.People.OfType<Employee>().ToList();
            if (!employees.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No employees found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // طلب المعرف من المستخدم وتحديد الموظف
            Console.Write("Enter Employee ID to edit: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid ID format.");
                Console.ResetColor();
                Pause();
                return;
            }

            var employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Employee not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Editing employee: {employee.Name}");
            Console.ResetColor();

            // التحقق من الإدخالات الجديدة وتعديل القيم إذا تم إدخالها
            string name = InputValidator.ReadValidatedName($"New Name (leave empty to keep '{employee.Name}')");
            if (!string.IsNullOrWhiteSpace(name)) employee.Name = name;

            string phone = InputValidator.ReadValidatedPhone($"New Phone (leave empty to keep '{employee.Phone}')");
            if (!string.IsNullOrWhiteSpace(phone)) employee.Phone = phone;

            Console.Clear();
            Console.Write($"New Age (leave empty to keep {employee.Age}): ");
            string ageInput = Console.ReadLine();
            if (int.TryParse(ageInput, out int newAge)) employee.Age = newAge;

            Console.Clear();
            Console.Write($"New Salary (leave empty to keep {employee.Salary}): ");
            string salaryInput = Console.ReadLine();
            if (decimal.TryParse(salaryInput, out decimal newSalary)) employee.Salary = newSalary;

            Console.Clear();
            Console.Write($"New Hire Date (yyyy-MM-dd) (leave empty to keep {employee.HireDate:yyyy-MM-dd}): ");
            string dateInput = Console.ReadLine();
            if (DateTime.TryParse(dateInput, out DateTime newHireDate)) employee.HireDate = newHireDate;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nEmployee updated successfully!");
            Console.ResetColor();

            Pause();
        }

        // حذف موظف
        public void DeleteEmployee(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== Delete Employee ===");
            Console.ResetColor();

            var employees = owner.People.OfType<Employee>().ToList();

            if (!employees.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No employees found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تحديد الموظف بناء على المعرف
            Console.Write("Enter Employee ID to delete: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid ID format.");
                Console.ResetColor();
                Pause();
                return;
            }

            var employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Employee not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تأكيد الحذف
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"Are you sure you want to delete employee '{employee.Name}'? (Y/N): ");
            Console.ResetColor();
            var confirm = Console.ReadKey(true).Key;

            if (confirm != ConsoleKey.Y)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nOperation canceled. Employee not deleted.");
                Console.ResetColor();
                Pause();
                return;
            }

            owner.People.Remove(employee);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nEmployee '{employee.Name}' deleted successfully.");
            Console.ResetColor();

            Pause();
        }

        // إيقاف مؤقت بانتظار إدخال المستخدم
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}







