﻿using PharmacySystem.Abstracts;
using PharmacySystem.Events;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;
using System.Linq;

namespace PharmacySystem.Services
{
    // فئة SalesServiceImpl مسؤولة عن إدارة عمليات البيع
    public class SalesServiceImpl : BaseService, ISalesService
    {
        // اسم الخدمة كما يُعرض في النظام
        public override string ServiceName => "Sales Management";

        // تعريف حدث يُطلق عند إضافة عملية بيع جديدة
        public event SaleAddedHandler SaleAdded;

        // باني الفئة يأخذ أدوات التفاعل مع المستخدم والتسجيل
        public SalesServiceImpl(IUserInteractor io, ILogger log) : base(io, log) { }

        // دالة إضافة عملية بيع جديدة
        public void AddSale(Owner owner, Employee emp)
        {
            Console.Clear();
            _log.Info("=== Add New Sale ===");

            // إدخال اسم الدواء والتحقق من وجوده على الرف
            string medicineName = InputValidator.ReadValidatedName("Medicine Name");
            var item = owner.Items.OfType<PharmacyItem>()
                .FirstOrDefault(i => string.Equals(i.MedicineName, medicineName, StringComparison.OrdinalIgnoreCase));

            if (item == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Medicine not found in shelves.");
                Console.ResetColor();
                Pause();
                return;
            }

            // إدخال كمية البيع والتحقق من توفر الكمية
            int quantity = InputValidator.ReadValidatedInt("Quantity Sold");
            if (quantity > item.Quantity)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Not enough stock. Available: {item.Quantity}");
                Console.ResetColor();
                Pause();
                return;
            }

            // إدخال السعر وتاريخ البيع
            decimal price = InputValidator.ReadValidatedDecimal("Unit Price");
            DateTime saleDate = InputValidator.ReadValidatedDate("Sale Date");

            // إنشاء سجل البيع الجديد
            var sale = new SaleRecord
            {
                MedicineName = item.MedicineName,
                QuantitySold = quantity,
                UnitPrice = price,
                SaleDate = saleDate,
                EmployeeID = emp?.Id ?? 0
            };

            // تعديل الكمية وإضافة السجل إلى قائمة المبيعات
            item.AdjustQuantity(-quantity);
            owner.AddSale(sale);

            // إطلاق الحدث لإعلام النظام بإضافة عملية بيع
            SaleAdded?.Invoke(this, new SaleEventArgs(sale));

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n✅ Sale recorded successfully for '{sale.MedicineName}'.");
            Console.ResetColor();

            Pause();
        }

        // دالة لعرض قائمة المبيعات
        public void ListSales(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== List of Sales ===");
            Console.ResetColor();

            var sales = owner.Sales.OfType<SaleRecord>().ToList();

            if (!sales.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No sales found.");
                Console.ResetColor();
                Pause();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (var s in sales)
            {
                Console.WriteLine($"ID: {s.Id}");
                Console.WriteLine($"Medicine: {s.MedicineName}");
                Console.WriteLine($"Quantity: {s.QuantitySold}");
                Console.WriteLine($"Price: {s.UnitPrice}");
                Console.WriteLine($"Total: {s.TotalAmount}");
                Console.WriteLine($"Date: {s.SaleDate:yyyy-MM-dd}");
                Console.WriteLine($"Employee ID: {s.EmployeeID}");
                Console.WriteLine(new string('-', 40));
            }

            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Sales: {sales.Count}");
            Console.ResetColor();

            Pause();
        }

        // دالة تعديل عملية بيع محددة حسب معرفها
        public void EditSale(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Edit Sale Record ===");

            var sales = owner.Sales.OfType<SaleRecord>().ToList();

            if (!sales.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No sales found.");
                Console.ResetColor();
                Pause();
                return;
            }

            int id = InputValidator.ReadValidatedInt("Enter Sale ID");
            var sale = sales.FirstOrDefault(s => s.Id == id);

            if (sale == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Sale not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Editing sale for '{sale.MedicineName}'");
            Console.ResetColor();

            // إدخال سعر جديد اختياريًا
            string priceInput = InputValidator.ReadValidatedDecimal("New Unit Price (leave empty to keep current)").ToString();
            if (decimal.TryParse(priceInput, out decimal newPrice))
                sale.UnitPrice = newPrice;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nSale record updated successfully!");
            Console.ResetColor();

            Pause();
        }

        // دالة حذف عملية بيع
        public void DeleteSale(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Delete Sale Record ===");

            var sales = owner.Sales.OfType<SaleRecord>().ToList();

            if (!sales.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No sales found.");
                Console.ResetColor();
                Pause();
                return;
            }

            int id = InputValidator.ReadValidatedInt("Enter Sale ID to delete");
            var sale = sales.FirstOrDefault(s => s.Id == id);

            if (sale == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Sale not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تأكيد الحذف من المستخدم
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"Are you sure you want to delete sale '{sale.MedicineName}'? (Y/N): ");
            Console.ResetColor();
            var confirm = Console.ReadKey(true).Key;

            if (confirm != ConsoleKey.Y)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nOperation canceled. Sale not deleted.");
                Console.ResetColor();
                Pause();
                return;
            }

            owner.Sales.Remove(sale);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nSale '{sale.MedicineName}' deleted successfully.");
            Console.ResetColor();

            Pause();
        }

        // دالة مساعدة لإيقاف البرنامج مؤقتًا حتى يضغط المستخدم Enter
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}