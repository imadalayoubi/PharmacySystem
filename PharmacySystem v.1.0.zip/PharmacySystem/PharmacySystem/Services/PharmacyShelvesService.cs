﻿using PharmacySystem.Abstracts;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Services
{
    public class PharmacyShelvesServiceImpl : BaseService, IPharmacyShelvesService
    {
        public override string ServiceName => "Pharmacy Shelves Management";

        public PharmacyShelvesServiceImpl(IUserInteractor io, ILogger log) : base(io, log) { }

        // -------------------------
        // إضافة دواء جديد
        // -------------------------
        public void AddMedicine(Owner owner, Employee emp)
        {
            Console.Clear();
            _log.Info("=== Add New Medicine ===");

            string name = InputValidator.ReadValidatedName("Medicine Name");
            decimal price = InputValidator.ReadValidatedDecimal("Price");
            DateTime expiryDate = InputValidator.ReadValidatedDate("Expiry Date");
            int quantity = InputValidator.ReadValidatedInt("Quantity");
            string location = InputValidator.ReadValidatedName("Location");

            var medicine = new PharmacyItem
            {
                MedicineName = name,
                Price = price,
                ExpiryDate = expiryDate,
                Location = location,
                EmployeeID = emp?.Id ?? 0
            };

            medicine.AdjustQuantity(quantity);
            owner.AddItem(medicine);

            Console.Clear();
            _log.Info($"Medicine '{medicine.MedicineName}' added successfully.");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nMedicine added successfully!");
            Console.ResetColor();

            Pause();
        }

        // -------------------------
        // عرض قائمة الأدوية
        // -------------------------
        public void ListMedicines(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== List of Medicines ===");
            Console.ResetColor();

            var medicines = owner.Items.OfType<PharmacyItem>().ToList();

            if (!medicines.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No medicines found.");
                Console.ResetColor();
                Pause();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (var med in medicines)
            {
                Console.WriteLine($"Type: {med.GetType().Name}");
                Console.WriteLine($"ID: {med.Id}");
                Console.WriteLine($"Name: {med.MedicineName}");
                Console.WriteLine($"Price: {med.Price}");
                Console.WriteLine($"Quantity: {med.Quantity}");
                Console.WriteLine($"Expiry: {med.ExpiryDate:yyyy-MM-dd}");
                Console.WriteLine($"Location: {med.Location}");
                Console.WriteLine(new string('-', 40));
            }

            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Medicines: {medicines.Count}");
            Console.ResetColor();

            Pause();
        }

        // -------------------------
        // تعديل بيانات دواء
        // -------------------------
        public void EditMedicine(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Edit Medicine ===");

            var medicines = owner.Items.OfType<PharmacyItem>().ToList();

            if (!medicines.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No medicines found.");
                Console.ResetColor();
                Pause();
                return;
            }

            int id = InputValidator.ReadValidatedInt("Enter Medicine ID");
            var medicine = medicines.FirstOrDefault(m => m.Id == id);

            if (medicine == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Medicine not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Editing medicine: {medicine.MedicineName}");
            Console.ResetColor();

            string newName = InputValidator.ReadValidatedName($"New Name (leave empty to keep '{medicine.MedicineName}')", true);
            if (!string.IsNullOrWhiteSpace(newName)) medicine.MedicineName = newName;

            string newLoc = InputValidator.ReadValidatedName($"New Location (leave empty to keep '{medicine.Location}')", true);
            if (!string.IsNullOrWhiteSpace(newLoc)) medicine.Location = newLoc;

            Console.Write($"New Price (leave empty to keep {medicine.Price}): ");
            string priceInput = Console.ReadLine();
            if (decimal.TryParse(priceInput, out decimal newPrice))
                medicine.Price = newPrice;

            Console.Write($"New Quantity (leave empty to keep {medicine.Quantity}): ");
            string qtyInput = Console.ReadLine();
            if (int.TryParse(qtyInput, out int newQty))
                medicine.AdjustQuantity(newQty - medicine.Quantity);

            Console.Write($"New Expiry Date (yyyy-MM-dd) (leave empty to keep {medicine.ExpiryDate:yyyy-MM-dd}): ");
            string dateInput = Console.ReadLine();
            if (DateTime.TryParse(dateInput, out DateTime newDate))
                medicine.ExpiryDate = newDate;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nMedicine updated successfully!");
            Console.ResetColor();

            Pause();
        }

        // -------------------------
        // حذف دواء
        // -------------------------
        public void DeleteMedicine(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Delete Medicine ===");

            var medicines = owner.Items.OfType<PharmacyItem>().ToList();

            if (!medicines.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No medicines found.");
                Console.ResetColor();
                Pause();
                return;
            }

            int id = InputValidator.ReadValidatedInt("Enter Medicine ID to delete");
            var medicine = medicines.FirstOrDefault(m => m.Id == id);

            if (medicine == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Medicine not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"Are you sure you want to delete '{medicine.MedicineName}'? (Y/N): ");
            Console.ResetColor();
            var confirm = Console.ReadKey(true).Key;

            if (confirm != ConsoleKey.Y)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nOperation canceled. Medicine not deleted.");
                Console.ResetColor();
                Pause();
                return;
            }

            owner.Items.Remove(medicine);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nMedicine '{medicine.MedicineName}' deleted successfully.");
            Console.ResetColor();

            Pause();
        }

        // -------------------------
        // دالة الإيقاف المؤقت
        // -------------------------
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}
