﻿using PharmacySystem.Events;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;

namespace PharmacySystem.Services
{
    // فئة ServiceRegistry تُستخدم لتجميع وربط جميع الخدمات المستخدمة في النظام
    public class ServiceRegistry
    {
        // خصائص للخدمات المختلفة، تُستخدم للتعامل مع بيانات الموظفين والعملاء والمخزون والمبيعات والشراء
        public IEmployeeService EmployeeService { get; }
        public ICustomerService CustomerService { get; }
        public IInventoryService InventoryService { get; }
        public IPharmacyShelvesService PharmacyShelvesService { get; }
        public ISalesService SalesService { get; }
        public IPurchaseService PurchaseService { get; }

        // متغيرات خاصة للاحتفاظ بمرجع للتفاعل مع المستخدم ولتسجيل الأحداث
        private readonly IUserInteractor _io;
        private readonly ILogger _log;
        private string _ownerPassword = "1688"; // كلمة مرور المالك الافتراضية

        // الباني يقوم بتهيئة جميع الخدمات وربط الأحداث اللازمة
        public ServiceRegistry(IUserInteractor io, ILogger log)
        {
            _io = io;
            _log = log;

            // إنشاء الكائنات المرتبطة بالخدمات وتمرير الواجهات اللازمة لها
            EmployeeService = new EmployeeServiceImpl(io, log);
            CustomerService = new CustomerServiceImpl(io, log);
            InventoryService = new InventoryServiceImpl(io, log);
            PharmacyShelvesService = new PharmacyShelvesServiceImpl(io, log);
            SalesService = new SalesServiceImpl(io, log);
            PurchaseService = new PurchaseServiceImpl(io, log);

            // ربط الأحداث (Delegates & Events) بالخدمات المناسبة
            ((SalesServiceImpl)SalesService).SaleAdded += OnSaleAdded;
            ((InventoryServiceImpl)InventoryService).LowStock += OnLowStock;
            ((PurchaseServiceImpl)PurchaseService).PurchaseAdded += OnPurchaseAdded;
        }

        // دالة لتغيير كلمة مرور المالك بعد التأكد من صحة الحالية
        public void ChangeOwnerPassword()
        {
            _log.Info("=== Change Owner Password ===");
            Console.Write("Enter current password: ");
            string current = Console.ReadLine()?.Trim();

            if (current != _ownerPassword)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Incorrect password.");
                Console.ResetColor();
                return;
            }

            Console.Write("Enter new password: ");
            string newPassword = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(newPassword))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Password cannot be empty.");
                Console.ResetColor();
                return;
            }

            _ownerPassword = newPassword;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Password changed successfully.");
            Console.ResetColor();
        }

        // دالة التحقق من كلمة مرور المالك عند الدخول إلى قائمة خاصة
        public bool VerifyOwnerPassword()
        {
            Console.Write("Enter password to access Owner Menu: ");
            string input = Console.ReadLine()?.Trim();
            return input == _ownerPassword;
        }

        // بدء تشغيل واجهة المستخدم مع تمرير المالك والخدمات
        public void Run(Owner owner)
        {
            ConsoleUI.Start(owner, this, _io);
        }

        // الحدث المرتبط بإضافة عملية بيع جديدة – يعرض إشعار على الشاشة
        private void OnSaleAdded(object sender, SaleEventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n[EVENT] ✅ Sale Added → {e.Sale.MedicineName}, Qty:{e.Sale.QuantitySold}, Total:{e.Sale.TotalAmount}");
            Console.ResetColor();
        }

        // الحدث المرتبط بانخفاض كمية منتج في المخزون – يعرض تحذير على الشاشة
        private void OnLowStock(object sender, LowStockEventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n[EVENT] ⚠️ Low Stock → {e.Item.MedicineName}, Remaining:{e.Item.Quantity}");
            Console.ResetColor();
        }

        // الحدث المرتبط بإضافة عملية شراء جديدة – يعرض إشعار على الشاشة
        private void OnPurchaseAdded(object sender, PurchaseEventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\n[EVENT] 🛒 Purchase Added → {e.Purchase.MedicineName}, Qty:{e.Purchase.QuantityPurchased}, Cost:{e.Purchase.PurchasePrice}");
            Console.ResetColor();
        }
    }
}