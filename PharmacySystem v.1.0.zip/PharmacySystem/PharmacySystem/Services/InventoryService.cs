﻿using PharmacySystem.Abstracts;
using PharmacySystem.Events;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;
using System.Linq;

namespace PharmacySystem.Services
{
    // فئة مسؤولة عن إدارة مخزون المستودع وتنفيذ العمليات عليه
    public class InventoryServiceImpl : BaseService, IInventoryService
    {
        // اسم الخدمة المعروضة في الواجهة
        public override string ServiceName => "Inventory Management";

        // حدث يتم إطلاقه عند انخفاض كمية المخزون لأحد العناصر
        public event LowStockHandler LowStock;

        // مُنشئ الفئة يستقبل أدوات التفاعل والتسجيل
        public InventoryServiceImpl(IUserInteractor io, ILogger log) : base(io, log) { }

        // إضافة عنصر جديد إلى مخزون المستودع
        public void AddWarehouseItem(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Add Warehouse Item ===");

            // قراءة البيانات الأساسية للدواء من المستخدم
            string name = InputValidator.ReadValidatedName("Medicine Name");
            string company = InputValidator.ReadValidatedName("Company Name");
            decimal shippingPrice = InputValidator.ReadValidatedDecimal("Shipping Price");
            DateTime expiryDate = InputValidator.ReadValidatedDate("Expiry Date");
            int quantity = InputValidator.ReadValidatedInt("Quantity");

            // إنشاء كائن جديد يمثل صنف دوائي في المستودع
            var newItem = new WarehouseItem
            {
                MedicineName = name,
                Company = company,
                ShippingPrice = shippingPrice,
                ExpiryDate = expiryDate
            };

            // تعديل الكمية وإضافة الصنف إلى قائمة المالك
            newItem.AdjustQuantity(quantity);
            owner.AddItem(newItem);

            Console.Clear();
            _log.Info($"Warehouse item '{newItem.MedicineName}' added successfully.");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nWarehouse item added successfully!");
            Console.ResetColor();

            Pause();
        }

        // عرض قائمة الأصناف الموجودة في المستودع
        public void ListWarehouse(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== Warehouse Inventory ===");
            Console.ResetColor();

            // استخراج الأصناف التي تنتمي إلى نوع WarehouseItem
            var items = owner.Items.OfType<WarehouseItem>().ToList();

            if (!items.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No warehouse items found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // طباعة بيانات كل صنف موجود
            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (var item in items)
            {
                Console.WriteLine($"Type: {item.GetType().Name}");
                Console.WriteLine($"ID: {item.Id}");
                Console.WriteLine($"Medicine: {item.MedicineName}");
                Console.WriteLine($"Company: {item.Company}");
                Console.WriteLine($"Shipping Price: {item.ShippingPrice}");
                Console.WriteLine($"Quantity: {item.Quantity}");
                Console.WriteLine($"Expiry: {item.ExpiryDate:yyyy-MM-dd}");
                Console.WriteLine(new string('-', 40));
            }

            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Items: {items.Count}");
            Console.ResetColor();

            Pause();
        }

        // تعديل كمية صنف محدد في المخزون
        public void AdjustQuantity(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Adjust Quantity ===");

            var items = owner.Items.OfType<WarehouseItem>().ToList();
            if (!items.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No warehouse items found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تحديد الصنف بناءً على المعرف
            int id = InputValidator.ReadValidatedInt("Enter Item ID");
            var item = items.FirstOrDefault(x => x.Id == id);

            if (item == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Item not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // قراءة التغير في الكمية وتعديله
            int delta = InputValidator.ReadValidatedInt("Quantity change (+/-)");
            item.AdjustQuantity(delta);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Quantity adjusted. New total: {item.Quantity}");
            Console.ResetColor();

            // إطلاق الحدث إذا انخفضت الكمية تحت الحد الأدنى
            if (item.Quantity < 5)
            {
                LowStock?.Invoke(this, new LowStockEventArgs(item));
            }

            Pause();
        }

        // حذف صنف من مخزون المستودع
        public void DeleteWarehouseItem(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Delete Warehouse Item ===");

            var items = owner.Items.OfType<WarehouseItem>().ToList();

            if (!items.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No warehouse items found.");
                Console.ResetColor();
                Pause();
                return;
            }

            int id = InputValidator.ReadValidatedInt("Enter Item ID to delete");
            var item = items.FirstOrDefault(x => x.Id == id);

            if (item == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Item not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تأكيد المستخدم قبل الحذف
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"Are you sure you want to delete '{item.MedicineName}'? (Y/N): ");
            Console.ResetColor();
            var confirm = Console.ReadKey(true).Key;

            if (confirm != ConsoleKey.Y)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nOperation canceled. Item not deleted.");
                Console.ResetColor();
                Pause();
                return;
            }

            // إزالة الصنف من قائمة المالك
            owner.Items.Remove(item);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nWarehouse item '{item.MedicineName}' deleted successfully.");
            Console.ResetColor();

            Pause();
        }

        // إيقاف مؤقت في واجهة المستخدم بانتظار ضغط المستخدم على Enter
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}













