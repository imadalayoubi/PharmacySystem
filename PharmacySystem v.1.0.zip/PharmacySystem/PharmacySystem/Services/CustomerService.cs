﻿using PharmacySystem.Abstracts;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;
using System.Linq;

namespace PharmacySystem.Services
{
    // فئة مسؤولة عن إدارة العملاء
    public class CustomerServiceImpl : BaseService, ICustomerService
    {
        // اسم الخدمة
        public override string ServiceName => "Customer Management";

        // مُنشئ الفئة يأخذ أدوات التفاعل والتسجيل    public class ConsoleInteractor : IUserInteractor
        public CustomerServiceImpl(IUserInteractor io, ILogger log) : base(io, log) { }

        // إضافة عميل جديد
        public void AddCustomer(Owner owner, Employee emp)
        {
            Console.Clear();
            _log.Info("=== Add New Customer ===");

            // قراءة البيانات الأساسية للعميل
            string name = InputValidator.ReadValidatedName("Customer Name");
            string phone = InputValidator.ReadValidatedPhone("Phone");

            // إنشاء كائن العميل وإضافته للمالك
            var newCustomer = new Customer
            {
                Name = name,
                Phone = phone
            };

            owner.AddPerson(newCustomer);

            Console.Clear();
            _log.Info($"Customer '{newCustomer.Name}' added successfully.");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nCustomer added successfully!");
            Console.ResetColor();

            Pause();
        }

        // عرض قائمة العملاء
        public void ListCustomers(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== List of Customers ===");
            Console.ResetColor();

            // استخراج جميع العملاء من الأشخاص
            var customers = owner.People.OfType<Customer>().ToList();

            if (!customers.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No customers found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // عرض بيانات كل عميل
            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (var customer in customers)
            {
                Console.WriteLine($"Type: {customer.GetType().Name}");
                Console.WriteLine($"ID: {customer.Id}");
                Console.WriteLine($"Name: {customer.Name}");
                Console.WriteLine($"Phone: {customer.Phone}");
                Console.WriteLine(new string('-', 40));
            }

            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Customers: {customers.Count}");
            Console.ResetColor();

            Pause();
        }

        // حذف عميل من النظام
        public void DeleteCustomer(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== Delete Customer ===");
            Console.ResetColor();

            var customers = owner.People.OfType<Customer>().ToList();

            if (!customers.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No customers found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // إدخال معرف العميل للحذف
            Console.Write("Enter Customer ID to delete: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid ID format.");
                Console.ResetColor();
                Pause();
                return;
            }

            // التحقق من وجود العميل
            var customer = customers.FirstOrDefault(c => c.Id == id);
            if (customer == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Customer not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تأكيد الحذف
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"Are you sure you want to delete customer '{customer.Name}'? (Y/N): ");
            Console.ResetColor();
            var confirm = Console.ReadKey(true).Key;

            if (confirm != ConsoleKey.Y)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nOperation canceled. Customer not deleted.");
                Console.ResetColor();
                Pause();
                return;
            }

            // حذف العميل
            owner.People.Remove(customer);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nCustomer '{customer.Name}' deleted successfully.");
            Console.ResetColor();

            Pause();
        }

        // إيقاف مؤقت لواجهة المستخدم
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}






