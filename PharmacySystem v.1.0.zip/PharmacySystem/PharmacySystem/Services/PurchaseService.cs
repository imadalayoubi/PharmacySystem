﻿using PharmacySystem.Abstracts;
using PharmacySystem.Events;
using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Utils;
using System;
using System.Linq;

namespace PharmacySystem.Services
{
    // فئة PurchaseServiceImpl تُعنى بإدارة عمليات الشراء في النظام
    public class PurchaseServiceImpl : BaseService, IPurchaseService
    {
        // اسم الخدمة كما يظهر في النظام
        public override string ServiceName => "Purchase Management";

        // تعريف الحدث الذي يُطلق عند إضافة عملية شراء
        public event PurchaseAddedHandler PurchaseAdded;

        // باني الفئة يستقبل أدوات التفاعل وتسجيل الأحداث
        public PurchaseServiceImpl(IUserInteractor io, ILogger log) : base(io, log) { }

        // دالة لإضافة عملية شراء جديدة إلى سجل المالك
        public void AddPurchase(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Add Purchase ===");

            // قراءة بيانات الشراء من المستخدم
            string med = InputValidator.ReadValidatedName("Medicine Name");
            string company = InputValidator.ReadValidatedName("Company Name");
            decimal purchasePrice = InputValidator.ReadValidatedDecimal("Purchase Price");
            int qty = InputValidator.ReadValidatedInt("Quantity Purchased");
            DateTime date = InputValidator.ReadValidatedDate("Purchase Date");

            // إنشاء كائن Purchase يمثل العملية
            var purchase = new Purchase
            {
                MedicineName = med,
                Company = company,
                PurchasePrice = purchasePrice,
                QuantityPurchased = qty,
                PurchaseDate = date
            };

            // إضافة العملية إلى سجل المالك
            owner.AddPurchase(purchase);

            // إطلاق الحدث المرتبط بإضافة الشراء
            PurchaseAdded?.Invoke(this, new PurchaseEventArgs(purchase));

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n🛒 Purchase of '{purchase.MedicineName}' added successfully!");
            Console.ResetColor();

            Pause();
        }

        // دالة لعرض جميع عمليات الشراء
        public void ListPurchases(Owner owner)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=== Purchase Records ===");
            Console.ResetColor();

            var purchases = owner.Purchases.ToList();

            if (!purchases.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No purchase records found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // طباعة تفاصيل كل عملية شراء
            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (var p in purchases)
            {
                Console.WriteLine($"Type: {p.GetType().Name}");
                Console.WriteLine($"ID: {p.InvoiceID}");
                Console.WriteLine($"Medicine: {p.MedicineName}");
                Console.WriteLine($"Company: {p.Company}");
                Console.WriteLine($"Quantity: {p.QuantityPurchased}");
                Console.WriteLine($"Price: {p.PurchasePrice}");
                Console.WriteLine($"Date: {p.PurchaseDate:yyyy-MM-dd}");
                Console.WriteLine(new string('-', 40));
            }

            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Purchases: {purchases.Count}");
            Console.ResetColor();

            Pause();
        }

        // دالة لحذف عملية شراء بناءً على رقم الفاتورة
        public void DeletePurchase(Owner owner)
        {
            Console.Clear();
            _log.Info("=== Delete Purchase ===");

            var purchases = owner.Purchases.ToList();
            if (!purchases.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No purchases found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // إدخال رقم الفاتورة والتحقق من وجودها
            int id = InputValidator.ReadValidatedInt("Enter Purchase ID");
            var p = purchases.FirstOrDefault(x => x.InvoiceID == id);
            if (p == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Purchase not found.");
                Console.ResetColor();
                Pause();
                return;
            }

            // تأكيد الحذف من المستخدم
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"Are you sure you want to delete '{p.MedicineName}'? (Y/N): ");
            Console.ResetColor();
            var confirm = Console.ReadKey(true).Key;

            if (confirm != ConsoleKey.Y)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nOperation canceled. Purchase not deleted.");
                Console.ResetColor();
                Pause();
                return;
            }

            owner.Purchases.Remove(p);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nPurchase '{p.MedicineName}' deleted successfully.");
            Console.ResetColor();

            Pause();
        }

        // دالة توقف مؤقت بانتظار إدخال المستخدم
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}






