﻿using PharmacySystem.Interfaces;
using System;

namespace PharmacySystem.Abstracts
{
    // صنف مجرد يمثل أساس جميع الخدمات (Services)
    public abstract class BaseService : IService
    {
        // كائن لإدارة الإدخال/الإخراج من المستخدم
        protected readonly IUserInteractor _io;

        // كائن لتسجيل الرسائل والسجلات
        protected readonly ILogger _log;

        // خاصية مجردة تمثل اسم الخدمة، يجب تنفيذها في الأصناف المشتقة
        public abstract string ServiceName { get; }

        // منشئ يحقن التبعيات الأساسية: واجهة الإدخال/الإخراج وواجهة التسجيل
        protected BaseService(IUserInteractor io, ILogger log)
        {
            _io = io ?? throw new ArgumentNullException(nameof(io));
            _log = log ?? throw new ArgumentNullException(nameof(log));
        }

        // دالة لطباعة عنوان تنسيقي في الواجهة
        protected void Title(string text)
        {
            _io.WriteLine("");
            _io.WriteLine(new string('-', 40));
            _io.WriteLine($"--- {text} ---");
            _io.WriteLine(new string('-', 40));
        }

        // دالة لطلب تأكيد من المستخدم بصيغة (نعم/لا)
        protected bool Confirm(string question)
        {
            string response = _io.ReadOption(question + " (y/n)", new[] { "y", "n" });
            return response.Equals("y", StringComparison.OrdinalIgnoreCase);
        }
    }
}







