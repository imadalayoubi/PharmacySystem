﻿using PharmacySystem.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Abstracts
{
    // صنف مجرد يمثل كيان شخص في النظام مثل موظف أو زبون أو مالك
    public abstract class Person : IEntity
    {
        // معرف فريد للشخص
        public int Id { get; protected set; }

        // اسم الشخص
        public string Name { get; set; }

        // رقم الهاتف
        public string Phone { get; set; }

        // دالة لعرض المعلومات، يجب تنفيذها في الأصناف المشتقة
        public abstract void ShowInfo();
    }

    // صنف مجرد يمثل كيان دواء أو منتج في النظام مثل أدوية الصيدلية أو المخزن
    public abstract class ItemBase : IEntity
    {
        // معرف فريد للعنصر
        public int Id { get; protected set; }

        // اسم الدواء
        public string MedicineName { get; set; }

        // تاريخ انتهاء الصلاحية
        public DateTime ExpiryDate { get; set; }

        // دالة لعرض المعلومات، يجب تنفيذها في الأصناف المشتقة
        public abstract void ShowInfo();
    }
}
