﻿using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Utils
{
    public static class ConsoleUI
    {
        public static void Start(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool running = true;
            while (running)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n--- MAIN MENU ---");
                Console.ResetColor();
                Console.WriteLine("1. Owner");
                Console.WriteLine("2. Employee");
                Console.WriteLine("3. Exit");

                string choice = io.ReadOption("Choose (1-3)", new[] { "1", "2", "3" });

                switch (choice)
                {
                    case "1":
                        OwnerMenu(owner, services, io);
                        break;
                    case "2":
                        EmployeeMenu(owner, services, io);
                        break;
                    case "3":
                        running = false;
                        new ConsoleLogger().Info("Exiting system...");
                        break;
                }
            }
        }

        // ---------------- OWNER MENU ----------------
        internal static void OwnerMenu(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            // ✅ تحقق من كلمة المرور قبل الدخول إلى قائمة المالك
            if (!services.VerifyOwnerPassword())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nAccess denied. Wrong password.");
                Console.ResetColor();
                io.Pause(); // أو Console.ReadLine() إذا لم يكن لديك io.Pause()
                return;
            }

            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n--- OWNER MENU ---");
                Console.ResetColor();

                Console.WriteLine("1. Employee Ops");
                Console.WriteLine("2. Warehouse");
                Console.WriteLine("3. Pharmacy Shelves");
                Console.WriteLine("4. Sales (Owner)");
                Console.WriteLine("5. Purchases");
                Console.WriteLine("6. Customers");
                Console.WriteLine("7. Change Password");
                Console.WriteLine("8. Back");

                string choice = io.ReadOption("Choose (1-8)", new[] { "1", "2", "3", "4", "5", "6", "7", "8" });

                switch (choice)
                {
                    case "1":
                        Owner_EmployeeOps(owner, services, io);
                        break;
                    case "2":
                        Owner_Warehouse(owner, services, io);
                        break;
                    case "3":
                        Owner_PharmacyShelves(owner, services, io);
                        break;
                    case "4":
                        Owner_Sales(owner, services, io);
                        break;
                    case "5":
                        Owner_Purchases(owner, services, io);
                        break;
                    case "6":
                        Owner_Customers(owner, services, io);
                        break;
                    case "7":
                        services.ChangeOwnerPassword();
                        Pause();
                        break;
                    case "8":
                        inMenu = false;
                        break;
                }
            }
        }


        // -------- Owner → Employee Ops --------
        private static void Owner_EmployeeOps(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Employee Ops ---");
                Console.WriteLine("1. Add Employee");
                Console.WriteLine("2. List Employees");
                Console.WriteLine("3. Edit Employee");
                Console.WriteLine("4. Delete Employee");
                Console.WriteLine("5. Back");

                string choice = io.ReadOption("Choose (1-5)", new[] { "1", "2", "3", "4", "5" });
                switch (choice)
                {
                    case "1": services.EmployeeService.AddEmployee(owner); Pause(); break;
                    case "2": services.EmployeeService.ListEmployees(owner); Pause(); break;
                    case "3": services.EmployeeService.EditEmployee(owner); break;
                    case "4": services.EmployeeService.DeleteEmployee(owner); Pause(); break;
                    case "5": inMenu = false; break;
                }
            }
        }

        // -------- Owner → Warehouse --------
        private static void Owner_Warehouse(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Warehouse ---");
                Console.WriteLine("1. Add Warehouse Item");
                Console.WriteLine("2. List Warehouse Items");
                Console.WriteLine("3. Adjust Quantity");
                Console.WriteLine("4. Delete Warehouse Item");
                Console.WriteLine("5. Back");

                string choice = io.ReadOption("Choose (1-5)", new[] { "1", "2", "3", "4", "5" });
                switch (choice)
                {
                    case "1": services.InventoryService.AddWarehouseItem(owner); Pause(); break;
                    case "2": services.InventoryService.ListWarehouse(owner); Pause(); break;
                    case "3": services.InventoryService.AdjustQuantity(owner); Pause(); break;
                    case "4": services.InventoryService.DeleteWarehouseItem(owner); Pause(); break;
                    case "5": inMenu = false; break;
                }
            }
        }

        // -------- Owner → Pharmacy Shelves --------
        private static void Owner_PharmacyShelves(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            Console.Clear();
            Console.WriteLine("\n--- Pharmacy Shelves (Owner) ---");
            services.PharmacyShelvesService.ListMedicines(owner);
            Pause();
        }

        // -------- Owner → Sales --------
        private static void Owner_Sales(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Sales (Owner) ---");
                Console.WriteLine("1. Add Sale");
                Console.WriteLine("2. List Sales");
                Console.WriteLine("3. Edit Sale");
                Console.WriteLine("4. Delete Sale");
                Console.WriteLine("5. Back");

                string choice = io.ReadOption("Choose (1-5)", new[] { "1", "2", "3", "4", "5" });
                switch (choice)
                {
                    case "1": services.SalesService.AddSale(owner, null); Pause(); break;
                    case "2": services.SalesService.ListSales(owner); Pause(); break;
                    case "3": services.SalesService.EditSale(owner); Pause(); break;
                    case "4": services.SalesService.DeleteSale(owner); Pause(); break;
                    case "5": inMenu = false; break;
                }
            }
        }

        // -------- Owner → Purchases --------
        private static void Owner_Purchases(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Purchases ---");
                Console.WriteLine("1. Add Purchase");
                Console.WriteLine("2. List Purchases");
                Console.WriteLine("3. Delete Purchase");
                Console.WriteLine("4. Back");

                string choice = io.ReadOption("Choose (1-4)", new[] { "1", "2", "3", "4" });
                switch (choice)
                {
                    case "1": services.PurchaseService.AddPurchase(owner); Pause(); break;
                    case "2": services.PurchaseService.ListPurchases(owner); Pause(); break;
                    case "3": services.PurchaseService.DeletePurchase(owner); Pause(); break;
                    case "4": inMenu = false; break;
                }
            }
        }

        // -------- Owner → Customers --------
        private static void Owner_Customers(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            Console.Clear();
            Console.WriteLine("\n--- Customers ---");
            io.WriteLine("No customer management here (Owner).");
            Pause();
        }
        // ---------------- EMPLOYEE MENU ----------------
        private static void EmployeeMenu(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n--- EMPLOYEE MENU ---");
                Console.ResetColor();

                Console.WriteLine("1. Customer Management");
                Console.WriteLine("2. Pharmacy Shelves");
                Console.WriteLine("3. Sales");
                Console.WriteLine("4. Back");

                string choice = io.ReadOption("Choose (1-4)", new[] { "1", "2", "3", "4" });
                switch (choice)
                {
                    case "1":
                        Employee_CustomerManagement(owner, services, io);
                        break;
                    case "2":
                        Employee_PharmacyShelves(owner, services, io);
                        break;
                    case "3":
                        Employee_Sales(owner, services, io);
                        break;
                    case "4":
                        inMenu = false;
                        break;
                }
            }
        }

        // -------- Employee → Customer Management --------
        private static void Employee_CustomerManagement(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Customer Management ---");
                Console.WriteLine("1. Add Customer");
                Console.WriteLine("2. List Customers");
                Console.WriteLine("3. Edit Customer");
                Console.WriteLine("4. Delete Customer");
                Console.WriteLine("5. Back");

                string choice = io.ReadOption("Choose (1-5)", new[] { "1", "2", "3", "4", "5" });
                switch (choice)
                {
                    case "1": services.CustomerService.AddCustomer(owner, null); Pause(); break;
                    case "2": services.CustomerService.ListCustomers(owner); Pause(); break;
                    case "3": io.WriteLine("Edit Customer (to be implemented)"); Pause(); break;
                    case "4": services.CustomerService.DeleteCustomer(owner); Pause(); break;
                    case "5": inMenu = false; break;
                }
            }
        }

        // -------- Employee → Pharmacy Shelves --------
        private static void Employee_PharmacyShelves(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Pharmacy Shelves (Employee) ---");
                Console.WriteLine("1. Add Medicine");
                Console.WriteLine("2. List Medicines");
                Console.WriteLine("3. Edit Medicine");
                Console.WriteLine("4. Back");

                string choice = io.ReadOption("Choose (1-4)", new[] { "1", "2", "3", "4" });
                switch (choice)
                {
                    case "1": services.PharmacyShelvesService.AddMedicine(owner, null); Pause(); break;
                    case "2": services.PharmacyShelvesService.ListMedicines(owner); Pause(); break;
                    case "3": services.PharmacyShelvesService.EditMedicine(owner); Pause(); break;
                    case "4": inMenu = false; break;
                }
            }
        }

        // -------- Employee → Sales --------
        private static void Employee_Sales(Owner owner, ServiceRegistry services, IUserInteractor io)
        {
            bool inMenu = true;
            while (inMenu)
            {
                Console.Clear();
                Console.WriteLine("\n--- Sales (Employee) ---");
                Console.WriteLine("1. Add Sale");
                Console.WriteLine("2. View My Sales");
                Console.WriteLine("3. Back");

                string choice = io.ReadOption("Choose (1-3)", new[] { "1", "2", "3" });
                switch (choice)
                {
                    case "1": services.SalesService.AddSale(owner, null); Pause(); break;
                    case "2": services.SalesService.ListSales(owner); Pause(); break;
                    case "3": inMenu = false; break;
                }
            }
        }
        private static void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadKey(true); // انتظر مفتاح واحد فقط بدل قراءة سطر
        }

        private static void Title(string text)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine($"\n--- {text} ---");
            Console.ResetColor();
        }
    }
}
