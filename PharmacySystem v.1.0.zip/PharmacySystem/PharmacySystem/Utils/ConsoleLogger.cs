﻿using PharmacySystem.Interfaces;
using System;

namespace PharmacySystem.Utils
{
    // تعريف فئة ConsoleLogger التي تطبق واجهة ILogger لتسجيل الرسائل في وحدة التحكم
    public class ConsoleLogger : ILogger
    {
        // تسجيل رسالة معلوماتية بلون أخضر
        public void Info(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green; // تغيير لون الخط إلى الأخضر
            Console.WriteLine($"[INFO] {message}");        // طباعة الرسالة مع بادئة [INFO]
            Console.ResetColor();                          // إعادة لون الخط للوضع الافتراضي
        }

        // تسجيل تحذير بلون أصفر
        public void Warn(string message)
        {
            Console.ForegroundColor = ConsoleColor.Yellow; // تغيير اللون إلى الأصفر
            Console.WriteLine($"[WARN] {message}");         // طباعة الرسالة مع بادئة [WARN]
            Console.ResetColor();                           // إعادة اللون الافتراضي
        }

        // تسجيل خطأ بلون أحمر
        public void Error(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;     // تغيير اللون إلى الأحمر
            Console.WriteLine($"[ERROR] {message}");         // طباعة الرسالة مع بادئة [ERROR]
            Console.ResetColor();                            // إعادة اللون الافتراضي
        }
    }
}
