﻿using PharmacySystem.Models;
using PharmacySystem.Services;
using System;
using System.Collections.Generic;

namespace PharmacySystem.UI
{
    public static class MenuRouter
    {
        private static readonly Dictionary<string, Action<Owner, ServiceRegistry>> _routes =
            new Dictionary<string, Action<Owner, ServiceRegistry>>
            {
                // ---------------------------
                // Employee Operations
                // ---------------------------
                { "1.1", (o, s) => s.EmployeeService.AddEmployee(o) },
                { "1.2", (o, s) => s.EmployeeService.ListEmployees(o) },
                { "1.3", (o, s) => s.EmployeeService.EditEmployee(o) },
                { "1.4", (o, s) => s.EmployeeService.DeleteEmployee(o) },

                // ---------------------------
                // Customer Operations
                // ---------------------------
                { "2.1", (o, s) => s.CustomerService.AddCustomer(o, null) }, // تمرير null مؤقتًا لمعامل Employee
                { "2.2", (o, s) => s.CustomerService.ListCustomers(o) },
                { "2.3", (o, s) => s.CustomerService.DeleteCustomer(o) },

                // ---------------------------
                // Warehouse Operations
                // ---------------------------
                { "3.1", (o, s) => s.InventoryService.AddWarehouseItem(o) },
                { "3.2", (o, s) => s.InventoryService.ListWarehouse(o) },
                { "3.3", (o, s) => s.InventoryService.AdjustQuantity(o) },
                { "3.4", (o, s) => s.InventoryService.DeleteWarehouseItem(o) },

                // ---------------------------
                // Pharmacy Shelves (Medicines)
                // ---------------------------
                { "4.1", (o, s) => s.PharmacyShelvesService.AddMedicine(o, null) },
                { "4.2", (o, s) => s.PharmacyShelvesService.ListMedicines(o) },
                { "4.3", (o, s) => s.PharmacyShelvesService.EditMedicine(o) },
                { "4.4", (o, s) => s.PharmacyShelvesService.DeleteMedicine(o) },

                // ---------------------------
                // Sales Operations
                // ---------------------------
                { "5.1", (o, s) => s.SalesService.AddSale(o, null) },
                { "5.2", (o, s) => s.SalesService.ListSales(o) },
                { "5.3", (o, s) => s.SalesService.EditSale(o) },
                { "5.4", (o, s) => s.SalesService.DeleteSale(o) },

                // ---------------------------
                // Purchase Operations
                // ---------------------------
                { "6.1", (o, s) => s.PurchaseService.AddPurchase(o) },
                { "6.2", (o, s) => s.PurchaseService.ListPurchases(o) },
                { "6.3", (o, s) => s.PurchaseService.DeletePurchase(o) },
            };

        public static void Execute(string key, Owner owner, ServiceRegistry services)
        {
            if (_routes.TryGetValue(key, out var action))
            {
                action(owner, services);
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n[Error] Menu '{key}' not implemented in router.");
                Console.ResetColor();
                Console.ReadKey(true);
            }
        }
    }
}