﻿using System;
using System.Text.RegularExpressions;

namespace PharmacySystem.Utils
{

    public static class InputValidator
    {
        //  قراءة اسم والتحقق من أنه لا يحتوي أرقام أو رموز
        public static string ReadValidatedName(string fieldName, bool allowEmpty = false)
        {
            while (true)
            {
                Console.Write($"{fieldName}: ");
                string input = Console.ReadLine()?.Trim();

                // السماح بالقيمة الفارغة إن تم تمرير allowEmpty=true
                if (string.IsNullOrEmpty(input) && allowEmpty)
                    return input;

                if (string.IsNullOrEmpty(input))
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Input cannot be empty.");
                    Console.ResetColor();
                    continue;
                }

                if (!Regex.IsMatch(input, @"^[a-zA-Z\s]+$"))
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("You can’t enter numbers (123..) or special characters(!@#..)");
                    Console.ResetColor();
                    continue;
                }

                return input;
            }
        }

        //  قراءة رقم هاتف والتحقق من كونه أرقام فقط
        public static string ReadValidatedPhone(string fieldName)
        {
            while (true)
            {
                Console.Write($"{fieldName}: ");
                string input = Console.ReadLine()?.Trim();

                if (string.IsNullOrEmpty(input))
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Phone cannot be empty.");
                    Console.ResetColor();
                    continue;
                }

                if (!Regex.IsMatch(input, @"^[0-9]+$"))
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("You can’t enter character (A-Z) or special characters(!@#..)");
                    Console.ResetColor();
                    continue;
                }

                return input;
            }
        }

        //  قراءة عدد صحيح
        public static int ReadValidatedInt(string fieldName)
        {
            while (true)
            {
                Console.Write($"{fieldName}: ");
                string input = Console.ReadLine()?.Trim();

                if (int.TryParse(input, out int value) && value >= 0)
                    return value;

                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You can’t enter character (A-Z) or special characters(!@#..)");
                Console.ResetColor();
            }
        }

        //  قراءة رقم عشري
        public static decimal ReadValidatedDecimal(string fieldName)
        {
            while (true)
            {
                Console.Write($"{fieldName}: ");
                string input = Console.ReadLine()?.Trim();

                if (decimal.TryParse(input, out decimal value) && value >= 0)
                    return value;

                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You can’t enter character (A-Z) or special characters(!@#..)");
                Console.ResetColor();
            }
        }

        //  قراءة التاريخ على ثلاث خطوات السنة ثم الشهر ثم اليوم
        public static DateTime ReadValidatedDate(string fieldName)
        {
            int year, month, day;

            while (true)
            {
                Console.Write($"{fieldName} - Year (yyyy): ");
                if (!int.TryParse(Console.ReadLine(), out year) || year < 1900 || year > DateTime.Now.Year + 10)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid year format.");
                    Console.ResetColor();
                    continue;
                }
                break;
            }

            while (true)
            {
                Console.Write("Month (1-12): ");
                if (!int.TryParse(Console.ReadLine(), out month) || month < 1 || month > 12)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid month format.");
                    Console.ResetColor();
                    continue;
                }
                break;
            }

            while (true)
            {
                Console.Write("Day (1-31): ");
                if (!int.TryParse(Console.ReadLine(), out day) || day < 1 || day > 31)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid day format.");
                    Console.ResetColor();
                    continue;
                }
                break;
            }

            return new DateTime(year, month, day);
        }
    }

}
