﻿using System.Threading;

namespace PharmacySystem.Utils
{
    //تخليق_id
    public static class IdGenerator
    {
        private static int _counter = 0;

        public static int NextId() => Interlocked.Increment(ref _counter);
    }
}
