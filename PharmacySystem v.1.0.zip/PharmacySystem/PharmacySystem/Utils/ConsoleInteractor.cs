﻿using PharmacySystem.Interfaces;
using System;

namespace PharmacySystem.Utils
{
    // تعريف فئة ConsoleInteractor التي تطبق واجهة IUserInteractor
    // تُستخدم للتفاعل مع المستخدم عبر واجهة سطر الأوامر
    public class ConsoleInteractor : IUserInteractor
    {
        // قراءة سلسلة نصية من المستخدم مع تحقق من الفراغ
        public string ReadString(string prompt, bool allowEmpty = false)
        {
            while (true)
            {
                Console.Write($"{prompt}: ");                         // طباعة الرسالة التعريفية
                string input = Console.ReadLine();                    // قراءة إدخال المستخدم
                if (allowEmpty || !string.IsNullOrWhiteSpace(input)) // التحقق من الشرط
                    return input.Trim();                              // إرجاع النص بعد إزالة الفراغات

                ConsoleLogger temp = new ConsoleLogger();             // إنشاء مسجل مؤقت لعرض خطأ
                temp.Error("Input cannot be empty. Try again.");
            }
        }

        // قراءة عدد صحيح من المستخدم مع خيار السماح بالأعداد السالبة
        public int ReadInt(string prompt, bool allowNegative = false)
        {
            while (true)
            {
                Console.Write($"{prompt}: ");
                string input = Console.ReadLine();
                if (int.TryParse(input, out int value) && (allowNegative || value >= 0))
                    return value;

                new ConsoleLogger().Error("Invalid integer. Try again.");
            }
        }

        // قراءة عدد عشري من المستخدم مع خيار السماح بالقيم السالبة
        public decimal ReadDecimal(string prompt, bool allowNegative = false)
        {
            while (true)
            {
                Console.Write($"{prompt}: ");
                string input = Console.ReadLine();
                if (decimal.TryParse(input, out decimal value) && (allowNegative || value >= 0))
                    return value;

                new ConsoleLogger().Error("Invalid decimal. Try again.");
            }
        }

        // قراءة تاريخ من المستخدم بصيغة yyyy-MM-dd
        public DateTime ReadDate(string prompt)
        {
            while (true)
            {
                Console.Write($"{prompt} (yyyy-MM-dd): ");
                string input = Console.ReadLine();
                if (DateTime.TryParse(input, out DateTime date))
                    return date;

                new ConsoleLogger().Error("Invalid date format. Try again.");
            }
        }

        // قراءة خيار من مجموعة خيارات محددة مسبقًا
        public string ReadOption(string prompt, string[] valid)
        {
            while (true)
            {
                Console.Write($"{prompt}: ");
                string input = Console.ReadLine()?.Trim();
                if (input == null) continue;
                foreach (string v in valid)
                    if (string.Equals(v, input, StringComparison.OrdinalIgnoreCase))
                        return input;
                new ConsoleLogger().Error("Invalid option. Try again.");
            }
        }

        // كتابة سطر نصي في وحدة التحكم
        public void WriteLine(string text) => Console.WriteLine(text);

        // قراءة سطر من المستخدم
        public string ReadLine()
        {
            return Console.ReadLine();
        }

        // دالة للتوقف المؤقت (غير مُنفّذة حاليًا)
        public void Pause()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\nPress Enter to continue...");
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}
