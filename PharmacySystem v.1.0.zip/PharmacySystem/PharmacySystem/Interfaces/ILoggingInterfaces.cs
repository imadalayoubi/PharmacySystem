﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Interfaces
{
    // واجهة لتسجيل الرسائل - توفر طرق لتسجيل معلومات، تحذيرات، وأخطاء
    public interface ILogger
    {
        void Info(string message);   // تسجيل رسالة معلوماتية
        void Warn(string message);   // تسجيل تحذير
        void Error(string message);  // تسجيل خطأ
    }

    // واجهة لعمليات الإدخال والإخراج - تسهّل التعامل التفاعلي مع المستخدم
    public interface IUserInteractor
    {
        string ReadString(string prompt, bool allowEmpty = false);              // قراءة سلسلة نصية
        int ReadInt(string prompt, bool allowNegative = false);                 // قراءة عدد صحيح
        decimal ReadDecimal(string prompt, bool allowNegative = false);         // قراءة عدد عشري
        DateTime ReadDate(string prompt);                                       // قراءة تاريخ
        string ReadOption(string prompt, string[] valid);                       // قراءة خيار من قائمة
        void WriteLine(string text);                                            // طباعة سطر نصي
        string ReadLine();                                                      // قراءة سطر من المستخدم
        void Pause();
    }
}