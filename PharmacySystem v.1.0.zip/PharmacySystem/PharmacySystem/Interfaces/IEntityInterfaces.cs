﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Interfaces
{
    // واجهة عامة لكل كيان يحتوي على معرف فريد
    public interface IIdentifiable
    {
        int Id { get; }
    }

    // واجهة عامة لأي كيان يمكن عرضه أو طباعته
    public interface IEntity : IIdentifiable
    {
        void ShowInfo();
    }
}
