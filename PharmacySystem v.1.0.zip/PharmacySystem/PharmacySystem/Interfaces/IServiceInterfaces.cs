﻿using PharmacySystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacySystem.Interfaces
{
    // ✅ واجهة أساسية للخدمات تحتوي فقط على اسم الخدمة
    public interface IService
    {
        string ServiceName { get; }
    }

    // ✅ واجهة لخدمة إدارة الموظفين
    public interface IEmployeeService : IService
    {
        void AddEmployee(Owner owner);              // إضافة موظف جديد
        void ListEmployees(Owner owner);            // عرض قائمة الموظفين
        void DeleteEmployee(Owner owner);           // حذف موظف
        void EditEmployee(Owner o);                 // تعديل بيانات موظف
    }

    // ✅ واجهة لخدمة إدارة العملاء
    public interface ICustomerService : IService
    {
        void AddCustomer(Owner owner, Employee emp); // إضافة عميل
        void ListCustomers(Owner owner);             // عرض العملاء
        void DeleteCustomer(Owner owner);            // حذف عميل
    }

    // ✅ واجهة لخدمة إدارة المخزون (المخزن)
    public interface IInventoryService : IService
    {
        void AddWarehouseItem(Owner owner);         // إضافة صنف للمخزن
        void ListWarehouse(Owner owner);            // عرض محتويات المخزن
        void AdjustQuantity(Owner owner);           // تعديل كمية صنف
        void DeleteWarehouseItem(Owner owner);      // حذف صنف من المخزن
    }

    // ✅ واجهة لخدمة إدارة رفوف الصيدلية
    public interface IPharmacyShelvesService : IService
    {
        void AddMedicine(Owner owner, Employee emp); // إضافة دواء
        void ListMedicines(Owner owner);             // عرض الأدوية
        void EditMedicine(Owner owner);              // تعديل بيانات دواء
        void DeleteMedicine(Owner owner);            // حذف دواء
    }

    // ✅ واجهة لخدمة إدارة المشتريات
    public interface IPurchaseService : IService
    {
        void AddPurchase(Owner owner);              // تسجيل شراء جديد
        void ListPurchases(Owner owner);            // عرض المشتريات
        void DeletePurchase(Owner owner);           // حذف عملية شراء
    }

    // ✅ واجهة لخدمة إدارة المبيعات
    public interface ISalesService : IService
    {
        void AddSale(Owner owner, Employee emp);     // تسجيل عملية بيع
        void ListSales(Owner owner);                 // عرض المبيعات
        void EditSale(Owner owner);                  // تعديل عملية بيع
        void DeleteSale(Owner owner);                // حذف عملية بيع
    }
}


