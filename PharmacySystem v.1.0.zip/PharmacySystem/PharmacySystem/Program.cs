﻿using PharmacySystem.Interfaces;
using PharmacySystem.Models;
using PharmacySystem.Services;
using PharmacySystem.Utils;
using System;

namespace PharmacySystem
{
    public static class Program
    {
        public static void Main()
        {
            // عنوان النافذة
            System.Console.Title = "Pharmacy Management System";

            // إنشاء أدوات النظام
            ILogger logger = new ConsoleLogger();
            IUserInteractor io = new ConsoleInteractor();

            // إنشاء المالك الرئيسي للنظام
            Owner owner = new Owner
            {
                Name = "Main Owner",
                Phone = "0999999999"
            };

            //  إضافة البيانات التجريبية قبل تشغيل النظام
            owner.AddPerson(new Employee { Name = "Ali", Phone = "0999999999", Age = 27, Salary = 600, HireDate = DateTime.Now });
            owner.AddPerson(new Employee { Name = "Sara", Phone = "0988888888", Age = 25, Salary = 550, HireDate = DateTime.Now.AddMonths(-3) });
            owner.AddPerson(new Customer { Name = "Omar", Phone = "0977777777" });
            owner.AddPerson(new Employee
            {
                Name = "Ali Hassan",
                Phone = "0999999999",
                Age = 30,
                Salary = 800,
                HireDate = new DateTime(2023, 5, 20)
            });

            owner.AddPerson(new Employee
            {
                Name = "Sara Ahmed",
                Phone = "0988888888",
                Age = 27,
                Salary = 700,
                HireDate = new DateTime(2024, 1, 12)
            });

            owner.AddPerson(new Customer
            {
                Name = "Omar Khaled",
                Phone = "0933333333",
                EmployeeID = 1
            });

            owner.AddPerson(new Customer
            {
                Name = "Lina Samer",
                Phone = "0944444444",
                EmployeeID = 2
            });

            owner.AddItem(new WarehouseItem
            {
                MedicineName = "Paracetamol",
                Company = "Medco",
                ShippingPrice = 1500,
                ExpiryDate = new DateTime(2026, 6, 30)
            });

            owner.AddItem(new WarehouseItem
            {
                MedicineName = "Amoxicillin",
                Company = "HealthPlus",
                ShippingPrice = 2000,
                ExpiryDate = new DateTime(2025, 12, 15)
            });

            owner.AddItem(new PharmacyItem
            {
                MedicineName = "Aspirin",
                Price = 2500,
                ExpiryDate = new DateTime(2025, 8, 1),
                Location = "Shelf A1",
                EmployeeID = 1
            });

            owner.AddItem(new PharmacyItem
            {
                MedicineName = "Ibuprofen",
                Price = 3200,
                ExpiryDate = new DateTime(2026, 3, 10),
                Location = "Shelf B2",
                EmployeeID = 2
            });

            owner.AddPurchase(new Purchase
            {
                MedicineName = "Amoxicillin",
                QuantityPurchased = 200,
                PurchasePrice = 400000,
                PurchaseDate = new DateTime(2025, 1, 25)
            });

            owner.AddPurchase(new Purchase
            {
                MedicineName = "Paracetamol",
                QuantityPurchased = 150,
                PurchasePrice = 225000,
                PurchaseDate = new DateTime(2025, 2, 12)
            });

            owner.AddSale(new SaleRecord
            {
                MedicineName = "Aspirin",
                QuantitySold = 10,
                UnitPrice = 2500,
                EmployeeID = 1
            });

            owner.AddSale(new SaleRecord
            {
                MedicineName = "Ibuprofen",
                QuantitySold = 5,
                UnitPrice = 3200,
                EmployeeID = 2
            });

            // إنشاء مركز الخدمات يشمل كلمة السر المحفوظة
            ServiceRegistry services = new ServiceRegistry(io, logger);

            //  الآن شغّل النظام بعد إدخال البيانات
            services.Run(owner);
        }
    }
}
